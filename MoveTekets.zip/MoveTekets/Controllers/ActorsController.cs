﻿using Microsoft.AspNetCore.Mvc;
using MoveTekets.Data.Services;
using WebApplication1.Data;
using WebApplication1.Models;

namespace WebApplication1.Controllers
{
    public class ActorsController : Controller
    {

        private readonly IActorsService service;
        public ActorsController(IActorsService _service)
        {
            service = _service;
        }
        public async Task<IActionResult> Index()
        {
            var data = await service.GetAll();
            return View(data); 
        }

        public IActionResult Create()
        {
            return View();
        }

        //[HttpPost]
        //public async Task<IActionResult> Create(Actor actor)
        //{

        //    ModelState.Remove("ProfilePicture");

        //    if (!ModelState.IsValid)
        //    {
        //        var errors = ModelState.Values.SelectMany(v => v.Errors);
        //        foreach (var error in errors)
        //        {
        //            Console.WriteLine(error.ErrorMessage);
        //        }
        //        return View(actor);
        //    }

        //    // Store the path of the image
        //    string wwwRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", "Actors");
        //    if (!Directory.Exists(wwwRootPath))
        //        Directory.CreateDirectory(wwwRootPath);

        //    string fileName = Guid.NewGuid().ToString() + Path.GetExtension(actor.ProfilePictureFile.FileName);
        //    string filePath = Path.Combine(wwwRootPath, fileName);

        //    using (var stream = new FileStream(filePath, FileMode.Create))
        //    {
        //        await actor.ProfilePictureFile.CopyToAsync(stream);
        //    }

        //    actor.ProfilePicture = "/images/Actors/" + fileName;

        //    service.Add(actor);
        //    service.Save();
        //    return RedirectToAction(nameof(Index));
        //}

        [HttpPost]
        public async Task<IActionResult> Create(Actor actor)
        {
            // ✅ لازم نشيلها لأنها مش موجودة في DB
            ModelState.Remove("ProfilePicture");

            // ✅ شيل السطر القديم وحط دا بدلًا منه
            ModelState.Remove("ProfilePictureFile");

            if (!ModelState.IsValid)
            {
                var errors = ModelState.Values.SelectMany(v => v.Errors).Select(e => e.ErrorMessage).ToList();
                Console.WriteLine("==== MODELSTATE ERRORS ====");
                foreach (var err in errors)
                {
                    Console.WriteLine(err);
                }
                return View(actor);
            }

            // ✅ تأكد إن الملف وصل فعلًا
            if (actor.ProfilePictureFile == null)
            {
                ModelState.AddModelError("ProfilePictureFile", "Image is required");
                return View(actor);
            }

            // ✅ رفع الصورة داخل wwwroot/images/Actors
            string wwwRootPath = Path.Combine(Directory.GetCurrentDirectory(), "wwwroot", "images", "Actors");
            if (!Directory.Exists(wwwRootPath))
                Directory.CreateDirectory(wwwRootPath);

            string fileName = Guid.NewGuid().ToString() + Path.GetExtension(actor.ProfilePictureFile.FileName);
            string filePath = Path.Combine(wwwRootPath, fileName);

            using (var stream = new FileStream(filePath, FileMode.Create))
            {
                await actor.ProfilePictureFile.CopyToAsync(stream);
            }

            actor.ProfilePicture = "/images/Actors/" + fileName;

            service.Add(actor);
            service.Save();

            return RedirectToAction(nameof(Index));
        }

    }
}

