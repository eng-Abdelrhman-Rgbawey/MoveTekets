﻿namespace WebApplication1.Data.Enums
{
    public enum MovieCategory
    {
        Action = 1,
        Comedy,
        Drama,
        Documentary,
        Horror,
        Cartoon
    }
}
